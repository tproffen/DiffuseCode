#ifdef __cplusplus
extern "C" {
#endif

extern void write_int32(char*, char*, int_least32_t*);

extern void read_int32(char*, char*, int_least32_t*);

#ifdef __cplusplus
}
#endif
